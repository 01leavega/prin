import numpy as np
from jpype import *


def _to_java_class(data_type):
    """
    Converts numpy data type to equivalent Java class
    :param data_type: the numpy data type
    :return: The Java Class
    """
    if data_type == np.int32:
        return java.lang.Integer(0).getClass()  # .class not currently supported by jpype
    if data_type == np.int64:
        return java.lang.Long(0).getClass()  # .class not currently supported by jpype
    if data_type == np.float32:
        return java.lang.Float(0).getClass()  # .class not currently supported by jpype
    if data_type == np.float64:
        return java.lang.Double(0.0).getClass()  # .class not currently supported by jpype
    if data_type == np.bool:
        return java.lang.Boolean(False).getClass()  # .class not currently supported by jpype
    if data_type == np.object:
        return java.lang.String().getClass()  # .class not currently supported by jpype

    raise ValueError('dtype [{}] not currently supported'.format(data_type))


def to_data_table(df):
    bayes = JPackage("com.bayesserver")
    bayes_data = bayes.data

    data_table = bayes_data.DataTable()
    cols = data_table.getColumns()

    for name, data_type in df.dtypes.iteritems():
        java_class = _to_java_class(data_type)
        data_column = bayes_data.DataColumn(name, java_class)
        cols.add(data_column)

    for index, row in df.iterrows():
        data_table.getRows().add(row)

    return data_table
